HEAVEN ESCAPE STAYCATION — WEBSITE PACKAGE

Contents
- index.html: responsive site pages and sections
- style.css: cream/white and gold styling for desktop and mobile
- script.js: mobile navigation, October 2026 date picker, booking form helper
- assets/: existing promotional artwork supplied for the project

FREE PUBLISHING OPTION — GITHUB PAGES
1. Sign in to GitHub and create a new public repository (example: heaven-escape-staycation).
2. Upload index.html, style.css, script.js, and the entire assets folder.
3. Open repository Settings > Pages.
4. Choose Deploy from a branch, select main and /(root), then Save.
5. Wait for the published URL to appear in the Pages section.

Alternative: Netlify Drop at https://app.netlify.com/drop (account/availability requirements may vary).

IMPORTANT
- Prices and amenities are based on details previously supplied for this project. Confirm all rates and policies before accepting reservations.
- The availability display is not connected to a live booking system. Message the host to confirm.
- The form opens the Facebook page and displays a copyable booking message. It cannot automatically send a Messenger message or confirm a reservation.
- The included artwork is the existing promotional poster/flyer. The small gallery tiles are decorative placeholders, not actual unit photos. Replace with individual original room photos when available.
- Free hosting does not include a purchased custom domain.
